# Fairy-Tail
Info about characters from the anime, Fairy Tail
